export default {
  background: "#333",
  color: "#FFF"
};
