export default {
  background: "EEE",
  color: "#333"
};
